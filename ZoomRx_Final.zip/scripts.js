dragover = ev => {
  ev.preventDefault();
  ev.dataTransfer.dropEffect = "move";
};

dragstart = ev => {
  ev.dataTransfer.setData("text/plain", ev.target.id);
  ev.dataTransfer.effectAllowed = "move";
};

drop = ev => {
  ev.preventDefault();
  let data = ev.dataTransfer.getData("text");
  ev.target.closest(".board-column").appendChild(document.getElementById(data));
};
